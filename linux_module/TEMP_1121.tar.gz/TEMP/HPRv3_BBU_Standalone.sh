#!/bin/bash
# Version       : v1.0
# Function      : Execute Get bmc mac from node folder and ping if the IP is alive. 
# History       :
# 2024-10-30    | initial version
source ../commonlib
source ../record_time

execscript=$(basename $BASH_SOURCE)
echo "Current use script : ${execscript}"

set -x

switch_index=1

while getopts s:i: OPT; do
    case "${OPT}" in
        "s")
			RackSN=${OPTARG}
			check_sn ${RackSN}
			RackIPN=$(cat ${LOGPATH}/${RackSN}/rackipn.txt)
			RackAsset=$(cat ${LOGPATH}/${RackSN}/assetid.txt)
			wedge400IP=$(cat ${LOGPATH}/${RackSN}/RUSW/${switch_index}/mac_ip.txt)
		;;
        "i")
			index=${OPTARG}
			if [ -z "${index}" ];then
				print_help
				return 1
			fi 
		;;
        *)
			print_help
			return 1
		;;
    esac
done

BBU_Update_Process()
{
    UpdateAddress=$1
    BBUType=$2
    BBUVendor=$3
    TargetVer=$4
    echo "Need updated address ${address} with BBU type : ${BBUType} and BBU vendor : ${BBUVendor^^}"

    BBUImage=$(ls $TOOL/${BBUType}/${BBUVendor^^}/)
    if [ ${BBUVendor^^} == "PANASONIC" ] && [ ${BBUType} == "ORV3_HPR_BBU" ];then
        #update_status "$SN" "$folder" "$index" "$testitem" "BBU Update" 1
        echo "Send the update image to Wedge400"
        echo "Command : sshpass -p "0penBmc" scp $TOOL/${BBUType}/${BBUVendor^^}/${BBUImage} ${wedge400IP}:/tmp"
        sshpass -p "0penBmc" sshpass -p "0penBmc" scp $TOOL/${BBUType}/${BBUVendor^^}/${BBUImage} ${wedge400IP}:/tmp
        if [ ${PIPESTATUS[0]} -ne 0 ];then
            echo "Can't send the update image into Wedge400"
            show_fail_msg "Rack Module Information Test -- SCP Image"
            record_time "HPRv3_WG400_BBU_Standalone" total "HPRv3_WG400_BBU_Standalone;NA" "NA" "FAIL" "${RackSN}"
            #update_status "$SN" "$folder" "$index" "$testitem" "BBU Update" 3
            return 1
        else
            show_pass_msg "Rack Module Information Test -- SCP Image"
        fi

        echo "Update command : flock /tmp/modbus_dynamo_solitonbeam.lock /usr/local/bin/orv3-device-update-mailbox.py --vendor hpr_panasonic --addr ${UpdateAddress} /tmp/${BBUImage}"
        exeucte_test "flock /tmp/modbus_dynamo_solitonbeam.lock /usr/local/bin/orv3-device-update-mailbox.py --vendor hpr_panasonic --addr ${UpdateAddress} /tmp/${BBUImage}" "${wedge400IP}" | tee ${BBUUpdateLog} 
        Status=$(cat ${BBUUpdateLog} | grep "Upgrade success" | wc -l)
        newFWVer=$(cat ${BBUUpdateLog} | grep -A 4 "Upgrade success" | grep Version | awk -F ':' '{print$NF}' | tr -d ' ' )
        if [ ${Status} -eq 1 ];then
            if [ ${newFWVer} == "$TargetVer" ];then
                echo "The vendor ${BBUVendor^^} for ${BBUType} already update to target version ${TargetVer}"
            else
                echo "The vendor ${BBUVendor^^} for ${BBUType} can't update to target version ${TargetVer}, stop the test"
                #update_status "$SN" "$folder" "$index" "$testitem" "BBU Update" 3
                return 1
            fi
        else    
            echo "The vendor ${BBUVendor^^} for ${BBUType} can't update to target version ${TargetVer}, stop the test"
            #update_status "$SN" "$folder" "$index" "$testitem" "BBU Update" 3
            return 1
        fi
    elif [ ${BBUVendor^^} == "DELTA" ] && [ ${BBUType} == "ORV3_HPR_BBU" ] ;then

        echo "Send the update image to Wedge400"
        echo "Command : sshpass -p "0penBmc" scp $TOOL/${BBUType}/${BBUVendor^^}/${BBUImage} ${wedge400IP}:/tmp"
        sshpass -p "0penBmc" sshpass -p "0penBmc" scp $TOOL/${BBUType}/${BBUVendor^^}/${BBUImage} ${wedge400IP}:/tmp
        if [ ${PIPESTATUS[0]} -ne 0 ];then
            echo "Can't send the update image into Wedge400"
            show_fail_msg "Rack Module Information Test -- SCP Image"
            record_time "HPRv3_WG400_BBU_Standalone" total "HPRv3_WG400_BBU_Standalone;NA" "NA" "FAIL" "${RackSN}"
            #update_status "$SN" "$folder" "$index" "$testitem" "BBU Update" 3
            return 1
        else
            show_pass_msg "Rack Module Information Test -- SCP Image"
        fi

        echo "Update command : flock /tmp/modbus_dynamo_solitonbeam.lock /usr/local/bin/orv3-device-update-mailbox.py --vendor delta --addr ${UpdateAddress} /tmp/${BBUImage}"
        exeucte_test "flock /tmp/modbus_dynamo_solitonbeam.lock /usr/local/bin/orv3-device-update-mailbox.py --vendor delta --addr ${UpdateAddress} /tmp/${BBUImage}" "${wedge400IP}" | tee ${BBUUpdateLog} 
        Status=$(cat ${BBUUpdateLog} | grep "Upgrade success" | wc -l)
        newFWVer=$(cat ${BBUUpdateLog}  | grep -A 4 "Upgrade success" | grep Version | awk -F ':' '{print$2}' | tr -d ' ')
        if [ ${Status} -eq 1 ];then
            if [ ${newFWVer} == "$TargetVer" ];then
                echo "The vendor ${BBUVendor^^} for ${BBUType} already update to target version ${TargetVer}"
            else
                echo "The vendor ${BBUVendor^^} for ${BBUType} can't update to target version ${TargetVer}, stop the test"
                #update_status "$SN" "$folder" "$index" "$testitem" "BBU Update" 3
                return 1
            fi
        else    
            echo "The vendor ${BBUVendor^^} for ${BBUType} can't update to target version ${TargetVer}, stop the test"
            #update_status "$SN" "$folder" "$index" "$testitem" "BBU Update" 3
            return 1
        fi
    else
        echo "Can't get correct BBU vendor or BBU type, stop the test"
        #update_status "$SN" "$folder" "$index" "$testitem" "BBU Update" 3
        return 1
    fi
    #update_status "$SN" "$folder" "$index" "$testitem" "BBU Update" 2
}

Normal_HPRv3_BBU_Funtional_test()
{
    # echo "Syslog Check Test -- Before test"
    # exeucte_test "cel_syslog -l before_log -k" | tee ${diagnosticLog}

    # checkArr=("Save System Logs" "SEL has no entries" "Log check PCIe Bus Error" "Log check PCIe Error" "Log check Hardware Error" "Check (Un)Correctable Error" "Log check mcelog error")

    # for key in ${checkArr[@]}
    # do
    #     logResultCheck "LogCheck" "${key}" "PASS;NF" "before_log"
    #     if [ ${PIPESTATUS[0]} -ne 0 ];then
    #         show_fail_msg "Syslog Check Test -- ${key}" 
    #         return 1
    #     else
    #         show_pass_msg "Syslog Check Test -- ${key}" 
    #     fi
    # done

    #BBU_Address=("0x30" "0x31" "0x32" "0x33" "0x34" "0x35" "0x3A" "0x3B" "0x3C" "0x3D" "0x3E" "0x3F" "0x5A" "0x5B" "0x5C" "0x5D" "0x5E" "0x5F" "0x6A" "0x6B" "0x6C" "0x6D" "0x6E" "0x6F" "0x70" "0x71" "0x72" "0x73" "0x74" "0x75" "0x7A" "0x7B" "0x7C" "0x7D" "0x7E" "0x7F")
    
    ### 0224 Debug Using
    # BBU_Address=("0x30" "0x31" "0x32" "0x33" "0x34" "0x35" "0x3A" "0x3B" "0x3C" "0x3D" "0x3E" "0x3F" "0x5A" "0x5B" "0x5C" "0x5D" "0x5E" "0x5F" "0x6A" "0x6B" "0x6C" "0x6D" "0x6E" "0x6F" "0x70" "0x71" "0x72" "0x73" "0x74" "0x75" )
    HPR_BBU_AddressArr=($(cat ${RackmonLog} | grep -B 1 "ORV3_HPR_BBU" | grep "Device Address" | awk '{print$NF}'))
    echo "HPR BBU Address : ${HPR_BBU_AddressArr[@]}"

    declare -a PANASONIC_BBU_Data_Array=("03-100046" "BJ-A3C0001A0001" "^[0-9]{2}/[0-9]{4}$" "B1V4PAJ" "01" "02.29.19" "23")

    declare -a DELTA_BBU_Data_Array=("03-100043" "DPST-5500GXA" "^[0-9]{2}/[0-9]{4}$" "KGRDTW" "S0" "S1.04B01")

    for address in ${HPR_BBU_AddressArr[@]};do
        #update_status "$SN" "$folder" "$index" "$testitem" "BBU Address Check" 1
        record_time "HPRv3_WG400_BBU_Standalone" start "BBU Address ${address} Check" "${address}" "NA" "${RackSN}"
        exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address}" "${wedge400IP}" | tee ${BBULog} 
        logResultCheck "LogCheck" "Device Address" "NF;${address}" "${BBULog}"
        if [ ${PIPESTATUS[0]} -ne 0 ];then
            show_fail_msg "Rack Module Information Test -- ${address} BBU Address"
            record_time "HPRv3_WG400_BBU_Standalone" end "BBU Address ${address} Check" "${address}" "FAIL" "${RackSN}"
            record_time "HPRv3_WG400_BBU_Standalone" total "HPRv3_WG400_BBU_Standalone;NA" "NA" "FAIL" "${RackSN}"
            #update_status "$SN" "$folder" "$index" "$testitem" "BBU Address Check" 3
            return 1
        else
            show_pass_msg "Rack Module Information Test -- ${address} BBU Address"
		    record_time "HPRv3_WG400_BBU_Standalone" end "BBU Address ${address} Check" "${address}" "PASS" "${RackSN}"
            #update_status "$SN" "$folder" "$index" "$testitem" "BBU Address Check" 2
        fi

        #update_status "$SN" "$folder" "$index" "$testitem" "BBU Info Check" 1
	    exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address} --reg-name Manufacture_Name" "${wedge400IP}" | tee ${BBULog}
        BBUVendor=$(cat ${BBULog} | grep "Manufacture_Name<" | awk '{print$NF}' | tr -d '"')
        
        exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address} --reg-name \"Device Type\"" "${wedge400IP}" | tee ${BBULog}
        BBUType=$(cat ${BBULog} | grep "Device Type:" | awk '{print$NF}')

        if [ ${BBUType} == "ORV3_HPR_BBU" ];then
            if [ ${BBUVendor} == "Panasonic" ];then
                declare -a BBU_Array=("${PANASONIC_BBU_Data_Array[@]}")
            elif [ ${BBUVendor} == "Delta" ];then
                declare -a BBU_Array=("${DELTA_BBU_Data_Array[@]}")
            else
                echo "Can't get correct BBU vendor, stop the test"
                #update_status "$SN" "$folder" "$index" "$testitem" "BBU Info Check" 3
                return 1
            fi
        else
            echo "The address is not belongs to BBU, stop the test"
            #update_status "$SN" "$folder" "$index" "$testitem" "BBU Info Check" 3
            return 1
        fi

        echo "BBU Module Infotmation Check for address : ${address}"
        if [ ${BBUVendor} == "Panasonic" ];then
            BBUInfo=("Facebook_Part_Number" "Manufacture_Model" "Manufacture_Date" "MFR_Serial" "HW_Revision" "FW_Revision" "Battery_Pack_FW_Revision")
        else
            BBUInfo=("Facebook_Part_Number" "Manufacture_Model" "Manufacture_Date" "MFR_Serial" "HW_Revision" "FW_Revision")
        fi

        for i in "${!BBUInfo[@]}"; do
            exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address} --reg-name ${BBUInfo[$i]}" "${wedge400IP}" | tee ${BBULog}
            record_time "HPRv3_WG400_BBU_Standalone" start "BBU_${address}_Information_Check;${BBUInfo[$i]}" "${BBU_Array[$i]}" "NA" "${RackSN}"

		    if [ ${BBUInfo[$i]} == "Manufacture_Date" ];then
                logResultCheck "CheckEGREPFormat" "${BBUInfo[$i]}<" "NF;${BBU_Array[$i]}" "${BBULog}"
                if [ ${PIPESTATUS[0]} -ne 0 ];then
                    show_fail_msg "Rack Module Test -- BBU_${address}_Information_Check Test -> ${BBUInfo[$i]}"
                    record_time "HPRv3_WG400_BBU_Standalone" end "BBU_${address}_Information_Check;${BBUInfo[$i]}" "${BBU_Array[$i]}" "FAIL" "${RackSN}"
                    record_time "HPRv3_WG400_BBU_Standalone" total "HPRv3_WG400_BBU_Standalone;NA" "NA" "FAIL" "${RackSN}"
                    #update_status "$SN" "$folder" "$index" "$testitem" "BBU Info Check" 3
                    return 1
                else
                    show_pass_msg "Rack Module Test -- BBU_${address}_Information_Check Test -> ${BBUInfo[$i]}"
                    record_time "HPRv3_WG400_BBU_Standalone" end "BBU_${address}_Information_Check;${BBUInfo[$i]}" "${BBU_Array[$i]}" "PASS" "${RackSN}"
                    #update_status "$SN" "$folder" "$index" "$testitem" "BBU Info Check" 2
                fi
		    elif [ ${BBUInfo[$i]} == "MFR_Serial" ];then
                logResultCheck "CheckEGREPValue" "${BBUInfo[$i]}<" "NF;${BBU_Array[$i]}" "${BBULog}"
                if [ ${PIPESTATUS[0]} -ne 0 ];then
                    show_fail_msg "Rack Module Test -- BBU_${address}_Information_Check Test -> ${BBUInfo[$i]}"
                    record_time "HPRv3_WG400_BBU_Standalone" end "BBU_${address}_Information_Check;${BBUInfo[$i]}" "${BBU_Array[$i]}" "FAIL" "${RackSN}"
                    record_time "HPRv3_WG400_BBU_Standalone" total "HPRv3_WG400_BBU_Standalone;NA" "NA" "FAIL" "${RackSN}"
                    #update_status "$SN" "$folder" "$index" "$testitem" "BBU Info Check" 3
                    return 1
                else
                    show_pass_msg "Rack Module Test -- BBU_${address}_Information_Check Test -> ${BBUInfo[$i]}"
                    record_time "HPRv3_WG400_BBU_Standalone" end "BBU_${address}_Information_Check;${BBUInfo[$i]}" "${BBU_Array[$i]}" "PASS" "${RackSN}"
                    #update_status "$SN" "$folder" "$index" "$testitem" "BBU Info Check" 2
                fi
		    elif [ ${BBUInfo[$i]} == "Manufacture_Model" ];then
                logResultCheck "CheckWholeResult" "${BBUInfo[$i]}<;NF" "${BBU_Array[$i]}" "${BBULog}"
                if [ ${PIPESTATUS[0]} -ne 0 ];then
                    show_fail_msg "Rack Module Test -- BBU_${address}_Information_Check Test -> ${BBUInfo[$i]}"
                    record_time "HPRv3_WG400_BBU_Standalone" end "BBU_${address}_Information_Check;${BBUInfo[$i]}" "${BBU_Array[$i]}" "FAIL" "${RackSN}"
                    record_time "HPRv3_WG400_BBU_Standalone" total "HPRv3_WG400_BBU_Standalone;NA" "NA" "FAIL" "${RackSN}"
                    #update_status "$SN" "$folder" "$index" "$testitem" "BBU Info Check" 3
                    return 1
                else
                    show_pass_msg "Rack Module Test -- BBU_${address}_Information_Check Test -> ${BBUInfo[$i]}"
                    record_time "HPRv3_WG400_BBU_Standalone" end "BBU_${address}_Information_Check;${BBUInfo[$i]}" "${BBU_Array[$i]}" "PASS" "${RackSN}"
                    #update_status "$SN" "$folder" "$index" "$testitem" "BBU Info Check" 2
                fi
            elif [ ${BBUInfo[$i]} == "FW_Revision" ];then                 
                logResultCheck "LogCheck" "${BBUInfo[$i]}<" "NF;${BBU_Array[$i]}" "${BBULog}"                 
                if [ ${PIPESTATUS[0]} -ne 0 ];then                         
                    show_warn_msg "Rack Module Test -- BBU_${address}_Information_Check Test -> ${BBUInfo[$i]}"                          
                    echo "Need to update the FW for BBU, continue the update process"
                    BBU_Update_Process "$address" "$BBUType" "$BBUVendor" "${BBU_Array[$i]}"
                    if [ ${PIPESTATUS[0]} -eq 0 ];then
                        echo "The BBU type ${BBUType} for vendor ${BBUVendor} already updated, check the FW again"
                        exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address} --reg-name ${BBUInfo[$i]}" "${wedge400IP}" | tee ${BBULog}
                        logResultCheck "LogCheck" "${BBUInfo[$i]}<" "NF;${BBU_Array[$i]}" "${BBULog}"
                        if [ ${PIPESTATUS[0]} -eq 0 ];then
                            echo "The BBU FW already update to ${BBU_Array[$i]}, continue the test"
                        else
                            echo "The BBU FW don't update to ${BBU_Array[$i]}, stop the test"
                            record_time "HPRv3_WG400_BBU_Standalone" end "BBU_${address}_Information_Check;${BBUInfo[$i]}" "${BBU_Array[$i]}" "FAIL" "${RackSN}"
                            record_time "HPRv3_WG400_BBU_Standalone" total "HPRv3_WG400_BBU_Standalone;NA" "NA" "FAIL" "${RackSN}"
                            #update_status "$SN" "$folder" "$index" "$testitem" "BBU Info Check" 3
                            return 1
                        fi
                    else
                        echo "The BBU FW don't update to ${BBU_Array[$i]}, stop the test"
                        #update_status "$SN" "$folder" "$index" "$testitem" "BBU Info Check" 3
                        return 1
                    fi
                else                         
                    show_pass_msg "Rack Module Test -- BBU_${address}_Information_Check Test -> ${BBUInfo[$i]}"                         
                    record_time "HPRv3_WG400_BBU_Standalone" end "BBU_${address}_Information_Check;${BBUInfo[$i]}" "${BBU_Array[$i]}" "PASS" "${RackSN}"   
                    #update_status "$SN" "$folder" "$index" "$testitem" "BBU Info Check" 2              
                fi
            else
                logResultCheck "LogCheck" "${BBUInfo[$i]}<" "NF;${BBU_Array[$i]}" "${BBULog}"
                if [ ${PIPESTATUS[0]} -ne 0 ];then
                    show_fail_msg "Rack Module Test -- BBU_${address}_Information_Check Test -> ${BBUInfo[$i]}"
                    record_time "HPRv3_WG400_BBU_Standalone" end "BBU_${address}_Information_Check;${BBUInfo[$i]}" "${BBU_Array[$i]}" "FAIL" "${RackSN}"
                    record_time "HPRv3_WG400_BBU_Standalone" total "HPRv3_WG400_BBU_Standalone;NA" "NA" "FAIL" "${RackSN}"
                    #update_status "$SN" "$folder" "$index" "$testitem" "BBU Info Check" 3
                    return 1
                else
                    show_pass_msg "Rack Module Test -- BBU_${address}_Information_Check Test -> ${BBUInfo[$i]}"
                    record_time "HPRv3_WG400_BBU_Standalone" end "BBU_${address}_Information_Check;${BBUInfo[$i]}" "${BBU_Array[$i]}" "PASS" "${RackSN}"
                    #update_status "$SN" "$folder" "$index" "$testitem" "BBU Info Check" 2
                fi
            fi
        done
    done
}

base=$(basename $0)
testitem=${base%.*}
filename="${testitem}.log"
LOGFOLDER=${LOGPATH}/${RackSN}
startTime=$(date "+%F_%T" | sed -e "s/-//g" -e "s/://g")
RackmonLog=${LOGFOLDER}/RackMonLog.txt
BBULog=${LOGFOLDER}/BBULog.txt
BBUUpdateLog=${LOGFOLDER}/BBUUpdateLog.txt
LOGFILE=${LOGFOLDER}/log.txt

show_title_msg "${testitem}" | tee ${LOGFILE}
START=$(date)

record_time "HPRv3_WG400_BBU_Standalone" initial "" "" "" "$RackSN" 
ssh-keygen -R "${wedge400IP}" > /dev/null

Normal_HPRv3_BBU_Funtional_test | tee -a ${LOGFILE}
if [ "${PIPESTATUS[0]}" -ne "0" ];then
   	show_error_msg "HPRv3 BBU Standalone Test" | tee -a ${LOGFILE} 
   	show_fail | tee -a ${LOGFILE}
   	finalLog=${RackIPN}_${RackSN}_${RackAsset}_HPRv3_${switch_index}_BBUSTANDALONE_FAIL_${startTime}.log
   	record_time "HPRv3_WG400_BBU_Standalone" total "HPRv3_WG400_BBU_Standalone;NA" "NA" "FAIL" "${RackSN}"
	record_time "HPRv3_WG400_BBU_Standalone" show "" "" "" "${RackSN}" | tee -a ${LOGFILE}
	cat ${LOGPATH}/${RackSN}/summary_table_${station}.conf | tee -a ${LOGFILE}
	cat ${LOGFILE} > ${LOGPATH}/${RackSN}/${finalLog}
   	cp ${LOGPATH}/${RackSN}/${finalLog} /log/hprv3 > /dev/null
   	exit 1
fi

show_pass_msg "HPRv3 BBU Standalone Test" | tee -a ${LOGFILE}
show_pass | tee -a ${LOGFILE}
finalLog=${RackIPN}_${RackSN}_${RackAsset}_HPRv3_${switch_index}_BBUSTANDALONE_PASS_${startTime}.log
record_time "HPRv3_WG400_BBU_Standalone" total "HPRv3_WG400_BBU_Standalone;NA" "NA" "PASS" "${RackSN}"
record_time "HPRv3_WG400_BBU_Standalone" show "" "" "" "${RackSN}" | tee -a ${LOGFILE}
#cat ${LOGPATH}/${RackSN}/summary_table_${station}.conf | tee -a ${LOGFILE}
cat ${LOGFILE} > ${LOGPATH}/${RackSN}/${finalLog}
cp ${LOGPATH}/${RackSN}/${finalLog} /log/hprv3 > /dev/null
exit 0
