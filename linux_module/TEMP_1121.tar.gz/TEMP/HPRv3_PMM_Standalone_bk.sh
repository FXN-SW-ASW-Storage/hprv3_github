#!/bin/bash
# Version       : v1.0
# Function      : Execute Get bmc mac from node folder and ping if the IP is alive. 
# History       :
# 2024-10-30    | initial version
source ../commonlib
source ../record_time

execscript=$(basename $BASH_SOURCE)
echo "Current use script : ${execscript}"

set -x

switch_index=1

while getopts s:i: OPT; do
    case "${OPT}" in
        "s")
            RackSN=${OPTARG}
            check_sn ${RackSN}
            RackIPN=$(cat ${LOGPATH}/${RackSN}/rackipn.txt)
            RackAsset=$(cat ${LOGPATH}/${RackSN}/assetid.txt)
            wedge400IP=$(cat ${LOGPATH}/${RackSN}/RUSW/${switch_index}/mac_ip.txt) 
        ;;
        "i")
            index=${OPTARG}
            if [ -z "${index}" ];then
                print_help
                exit 1
            fi 
        ;;
        *)
            print_help
            exit 1
        ;;
    esac
done

Normal_HPRv3_GPIO_test()
{
    record_time "HPRv3_WG400_PMM_Standalone" start "Wedge400_GPIO_Test;NA" "6" "NA" "${RackSN}"
    echo "Rack Module Information Test - Wedge400 GPIO Test"
    #/usr/bin/python3 "Wedge400" "${wedge400Dev}" "BMC" "0" "NA" "/usr/local/bin/rackmoninfo"
    #cat ./log/Execution_console.log >> ${LOGFILE}
    exeucte_test "cat /tmp/gpionames/RMON*/value" "${wedge400IP}" | tee ${GPIOLog}
    GPIONum=$(cat $GPIOLog | egrep "1" | grep -v "*1*" | wc -l)
	if [ ${GPIONum} -ne 6 ];then
        show_fail_msg "Rack Module Information Test -- Wedge400 GPIO Test"
        record_time "HPRv3_WG400_PMM_Standalone" end "Wedge400_GPIO_Test;NA" "6" "FAIL" "${RackSN}"
        record_time "HPRv3_WG400_PMM_Standalone" total "HPRv3_WG400_PMM_Standalone;NA" "NA" "FAIL" "${RackSN}"
        return 1
    else
        show_pass_msg "Rack Module Information Test -- Wedge400 GPIO Test"
        record_time "HPRv3_WG400_PMM_Standalone" end "Wedge400_GPIO_Test;NA" "6" "PASS" "${RackSN}"
    fi
}

PMM_Update_Process()
{
    UpdateAddress=$1
    PMMType=$2
    PMMVendor=$3
    TargetVer=$4
    echo "Need updated address ${address} with PMM type : ${PMMType} and PMM vendor : ${PMMVendor}"

    PMMImage=$(ls $TOOLPATH/${PMMType}/${PMMVendor}/)
    if [ ${PMMVendor^^} == "ARTESYN" ] && [ ${PMMType} == "ORV3_HPR_PMM_PSU" ];then

        echo "Send the update image to Wedge400"
        echo "Command : sshpass -p "0penBmc" scp $TOOLPATH/${PMMType}/${PMMVendor}/${PMMImage} ${wedge400IP}:/tmp"
        sshpass -p "0penBmc" sshpass -p "0penBmc" scp $TOOLPATH/${PMMType}/${PMMVendor}/${PMMImage} ${wedge400IP}:/tmp
        if [ ${PIPESTATUS[0]} -ne 0 ];then
            echo "Can't send the update image into Wedge400"
            show_fail_msg "Rack Module Information Test -- SCP Image"
            record_time "HPRv3_WG400_PMM_Standalone" total "HPRv3_WG400_PMM_Standalone;NA" "NA" "FAIL" "${RackSN}"
            return 1
        else
            show_pass_msg "Rack Module Information Test -- SCP Image"
        fi

        echo "Update command : flock /tmp/modbus_dynamo_solitonbeam.lock /usr/local/bin/orv3-device-update-mailbox.py --addr ${UpdateAddress} --vendor hpr_pmm_aei /tmp/${PMMImage}"
        exeucte_test "flock /tmp/modbus_dynamo_solitonbeam.lock /usr/local/bin/orv3-device-update-mailbox.py --addr ${UpdateAddress} --vendor hpr_pmm_aei /tmp/${PMMImage}" "${wedge400IP}" | tee ${PMMUpdateLog} 
        Status=$(cat ${PMMUpdateLog} | grep "Upgrade success" | wc -l)
        newFWVer=$(cat ${PMMUpdateLog} | grep -A 4 "Upgrade success" | grep Version | awk -F ':' '{print$2}' | tr -d ' ' )
        if [ ${Status} -eq 1 ];then
            if [ ${newFWVer} == "$TargetVer" ];then
                echo "The vendor ${PMMVendor} for ${PMMType} PMM already update to target version ${TargetVer}"
            else
                echo "The vendor ${PMMVendor} for ${PMMType} PMM can't update to target version ${TargetVer}, stop the test"
                return 1
            fi
        else    
            echo "The vendor ${PMMVendor} for ${PMMType} PMM can't update to target version ${TargetVer}, stop the test"
            return 1
        fi

    elif [ ${PMMVendor^^} == "PANASONIC" ] && [ ${PMMType} == "ORV3_HPR_PMM_BBU" ];then

        echo "Send the update image to Wedge400"
        echo "Command : sshpass -p "0penBmc" scp $TOOLPATH/${PMMType}/${PMMVendor}/${PMMImage} ${wedge400IP}:/tmp"
        sshpass -p "0penBmc" sshpass -p "0penBmc" scp $TOOLPATH/${PMMType}/${PMMVendor}/${PMMImage} ${wedge400IP}:/tmp
        if [ ${PIPESTATUS[0]} -ne 0 ];then
            echo "Can't send the update image into Wedge400"
            show_fail_msg "Rack Module Information Test -- SCP Image"
            record_time "HPRv3_WG400_PMM_Standalone" total "HPRv3_WG400_PMM_Standalone;NA" "NA" "FAIL" "${RackSN}"
            return 1
        else
            show_pass_msg "Rack Module Information Test -- SCP Image"
        fi

        echo "Update command : flock /tmp/modbus_dynamo_solitonbeam.lock /usr/local/bin/orv3-device-update-mailbox.py --addr ${UpdateAddress} --vendor hpr_pmm_panasonic /tmp/${PMMImage}"
        exeucte_test "flock /tmp/modbus_dynamo_solitonbeam.lock /usr/local/bin/orv3-device-update-mailbox.py --addr ${UpdateAddress} --vendor hpr_pmm_panasonic /tmp/${PMMImage}" "${wedge400IP}" | tee ${PMMUpdateLog} 
        Status=$(cat ${PMMUpdateLog} | grep "Upgrade success" | wc -l)
        newFWVer=$(cat ${PMMUpdateLog} | grep -A 4 "Upgrade success" | grep Version | awk -F ':' '{print$2}' | tr -d ' ' )
        if [ ${Status} -eq 1 ];then
            if [ ${newFWVer} == "$TargetVer" ];then
                echo "The vendor ${PMMVendor} for ${PMMType} PMM already update to target version ${TargetVer}"
            else
                echo "The vendor ${PMMVendor} for ${PMMType} PMM can't update to target version ${TargetVer}, stop the test"
                return 1
            fi
        else    
            echo "The vendor ${PMMVendor} for ${PMMType} PMM can't update to target version ${TargetVer}, stop the test"
            return 1
        fi
    elif [ ${PMMVendor^^} == "DELTA" ] && [ ${PMMType} == "ORV3_HPR_PMM_PSU" ] ;then

        echo "Send the update image to Wedge400"
        echo "Command : sshpass -p "0penBmc" scp $TOOLPATH/${PMMType}/${PMMVendor}/${PMMImage} ${wedge400IP}:/tmp"
        sshpass -p "0penBmc" sshpass -p "0penBmc" scp $TOOLPATH/${PMMType}/${PMMVendor}/${PMMImage} ${wedge400IP}:/tmp
        if [ ${PIPESTATUS[0]} -ne 0 ];then
            echo "Can't send the update image into Wedge400"
            show_fail_msg "Rack Module Information Test -- SCP Image"
            record_time "HPRv3_WG400_PMM_Standalone" total "HPRv3_WG400_PMM_Standalone;NA" "NA" "FAIL" "${RackSN}"
            return 1
        else
            show_pass_msg "Rack Module Information Test -- SCP Image"
        fi

        echo "Update command : flock /tmp/modbus_dynamo_solitonbeam.lock /usr/local/bin/orv3-device-update-mailbox.py --addr ${UpdateAddress} --vendor hpr_pmm_delta /tmp/${PMMImage}"
        exeucte_test "flock /tmp/modbus_dynamo_solitonbeam.lock /usr/local/bin/orv3-device-update-mailbox.py --addr ${UpdateAddress} --vendor hpr_pmm_delta /tmp/${PMMImage}" "${wedge400IP}" | tee ${PMMUpdateLog} 
        Status=$(cat ${PMMUpdateLog} | grep "Upgrade success" | wc -l)
        newFWVer=$(cat ${PMMUpdateLog}  | grep -A 4 "Upgrade success" | grep Version | awk -F ':' '{print$2}' | tr -d ' ')
        if [ ${Status} -eq 1 ];then
            if [ ${newFWVer} == "$TargetVer" ];then
                echo "The vendor ${PMMVendor} for ${PMMType} PMM already update to target version ${TargetVer}"
            else
                echo "The vendor ${PMMVendor} for ${PMMType} PMM can't update to target version ${TargetVer}, stop the test"
                return 1
            fi
        else    
            echo "The vendor ${PMMVendor} for ${PMMType} PMM can't update to target version ${TargetVer}, stop the test"
            return 1
        fi
    else
        echo "Can't get correct PMM vendor or PMM type, stop the test"
        return 1
    fi
}

Normal_Wedge400_Gen_Whole_Log()
{
	record_time "HPRv3_WG400_PMM_Standalone" start "Wedge400_Whole_Log;NA" "NA" "NA" "${RackSN}"
	echo "Rack Module Information Test - Generate Whole Log"
    #/usr/bin/python3 "Wedge400" "${wedge400Dev}" "BMC" "0" "NA" "/usr/local/bin/rackmoninfo"
    #cat ./log/Execution_console.log >> ${LOGFILE}
    exeucte_test "/usr/local/bin/rackmoninfo" "${wedge400IP}" | tee ${RackmonLog} 
    logResultCheck "ShowOnly" "NA" "NA" "${RackmonLog}"
    if [ ${PIPESTATUS[0]} -ne 0 ];then
        show_fail_msg "Rack Module Information Test -- Generate Log"
        record_time "HPRv3_WG400_PMM_Standalone" end "Wedge400_Whole_Log;NA" "NA" "FAIL" "${RackSN}"
        record_time "HPRv3_WG400_PMM_Standalone" total "HPRv3_WG400_PMM_Standalone;NA" "NA" "FAIL" "${RackSN}"
        return 1
    else
        show_pass_msg "Rack Module Information Test -- Generate Log"
        record_time "HPRv3_WG400_PMM_Standalone" end "Wedge400_Whole_Log;NA" "NA" "PASS" "${RackSN}"
    fi   
}

Normal_HPRv3_PMM_Funtional_test()
{
    HPR_PMM_PSU_AddressArr=($(cat ${RackmonLog} | grep -B 1 "ORV3_HPR_PMM_PSU" | grep "Device Address" | awk '{print$NF}'))
    HPR_PMM_BBU_AddressArr=($(cat ${RackmonLog} | grep -B 1 "ORV3_HPR_PMM_BBU" | grep "Device Address" | awk '{print$NF}'))
    echo "HPR PSU PMM Address : ${HPR_PMM_PSU_AddressArr[@]}"
    echo "HPR BBU PMM Address : ${HPR_PMM_BBU_AddressArr[@]}"

    #declare -a ARTESYN_PSUPMM_Data_Array=("03-100050" "700-043397-0000" "[0-5][0-9]/202[4-5]" "PMM1AEL" "A00" "0006")
    declare -a ARTESYN_PSUPMM_Data_Array=("03-100050" "700-043397-0000" "^[0-9]{2}/[0-9]{4}$" "PMM1AEL" "A00" "0006")
    declare -a DELTA_PSUPMM_Data_Array=("03-100037" "ECD90000111" "^[0-9]{2}/[0-9]{4}$" "M2HPDET" "04" "1100")
    declare -a DELTA_BBUPMM_Data_Array=("03-100037" "ECD90000111" "^[0-9]{2}/[0-9]{4}$" "M2HPDES" "04" "1110")
    
    # Official
    #declare -a DELTA_BBUPMM_Data_Array=("03-100037" "ECD90000111" "^[0-9]{2}/[0-9]{4}$" "M2HPDET" "5" "1.0.1.0")
    #declare -a DELTA_BBUPMM_Data_Array=("14-100014" "SG-09QA" "^[0-9]{2}/[0-9]{4}$" "M2HPDET" "S3" "NA")
    #declare -a PANA_BBUPMM_Data_Array=("03-100048" "BJ-BPM102A0001" "[0-5][0-9]/202[4-5]" "M1V4PAM" "M01" "00.01.1F")
    declare -a PANA_BBUPMM_Data_Array=("03-100048" "BJ-BPM102A" "^[0-9]{2}/[0-9]{4}$" "M1V4PAM" "M01" "00.01.1F")

    for address in ${HPR_PMM_PSU_AddressArr[@]};do
	    record_time "HPRv3_WG400_PMM_Standalone" start "PSU_PMM_Check;${address}" "${address}" "NA" "${RackSN}"
        exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address}" "${wedge400IP}" | tee ${PMMLog} 
    	echo "PSU PMM Address and Modbus Address : ${address} Check Test"	
	    logResultCheck "CheckResult" "Device Address;NF" "${address}" "${PMMLog}"
        if [ ${PIPESTATUS[0]} -ne 0 ];then
            show_fail_msg "Rack Module Information Test -- PSU PMM Address and Modbus Check Test -- Address ${address} "
            record_time "HPRv3_WG400_PMM_Standalone" end "PSU_PMM_Check;${address}" "${address}" "FAIL" "${RackSN}"
            record_time "HPRv3_WG400_PMM_Standalone" total "HPRv3_WG400_PMM_Standalone;NA" "NA" "FAIL" "${RackSN}"
            return 1
        else
            show_pass_msg "Rack Module Information Test -- PSU PMM Address and Modbus Check Test -- Address ${address} "
		    record_time "HPRv3_WG400_PMM_Standalone" end "PSU_PMM_Check;${address}" "${address}" "PASS" "${RackSN}"
        fi

	    exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address} --reg-name PMM_MFR_Name" "${wedge400IP}" | tee ${PMMLog}
        PMMVendor=$(cat ${PMMLog} | grep "PMM_MFR_Name<0x0008>" | awk '{print $NF}' | tr -d '"')
	
	    exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address} --reg-name \"Device Type\"" "${wedge400IP}" | tee ${PMMLog}
        PMMType=$(cat ${PMMLog} | grep "Device Type:" | awk '{print$NF}')

        if [ ${PMMType} == "ORV3_HPR_PMM_PSU" ];then
            if [ ${PMMVendor} == "ARTESYN" ];then
                declare -a PMM_Array=("${ARTESYN_PSUPMM_Data_Array[@]}")
            elif [ ${PMMVendor} == "Delta" ];then
                declare -a PMM_Array=("${DELTA_PSUPMM_Data_Array[@]}")
            else
                echo "Can't get correct PSU PMM vendor, stop the test"
                return 1
            fi
        else
            echo "The address is not belongs to PSU PMM, stop the test"
            return 1
        fi

	    echo "PMM Module Inforamtion Check for address : ${address}" 
        PMMInfo=("PMM_FBPN" "PMM_MFR_Model" "PMM_MFR_Date" "PMM_MFR_Serial" "PMM_HW_Revision" "PMM_FW_Revision")
    
        for i in "${!PMMInfo[@]}"; do
            exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address} --reg-name ${PMMInfo[$i]}" "${wedge400IP}" | tee ${PMMLog}
            record_time "HPRv3_WG400_PMM_Standalone" start "PSU_${address}_PMM_Information_Check;${PMMInfo[$i]}" "${PMM_Array[$i]}" "NA" "${RackSN}"
            
            if [ ${PMMInfo[$i]} == "PMM_MFR_Date" ];then 
                logResultCheck "CheckEGREPFormat" "${PMMInfo[$i]}<" "NF;${PMM_Array[$i]}" "${PMMLog}"
                if [ ${PIPESTATUS[0]} -ne 0 ];then
                    show_fail_msg "Rack Module Test -- PSU_${address}_PMM_Information_Check Test -> ${PMMInfo[$i]}"
                    record_time "HPRv3_WG400_PMM_Standalone" end "PSU_${address}_PMM_Information_Check;${PMMInfo[$i]}" "${PMM_Array[$i]}" "FAIL" "${RackSN}"
                    record_time "HPRv3_WG400_PMM_Standalone" total "HPRv3_WG400_PMM_Standalone;NA" "NA" "FAIL" "${RackSN}"
                    return 1
                else
                    show_pass_msg "Rack Module Test -- PSU_${address}_PMM_Information_Check Test -> ${PMMInfo[$i]}"
                    record_time "HPRv3_WG400_PMM_Standalone" end "PSU_${address}_PMM_Information_Check;${PMMInfo[$i]}" "${PMM_Array[$i]}" "PASS" "${RackSN}"
                fi
            elif [ ${PMMInfo[$i]} == "PMM_MFR_Serial" ];then
                logResultCheck "CheckEGREPValue" "${PMMInfo[$i]}<" "NF;${PMM_Array[$i]}" "${PMMLog}"
                if [ ${PIPESTATUS[0]} -ne 0 ];then
                    show_fail_msg "Rack Module Test -- PSU_${address}_PMM_Information_Check Test -> ${PMMInfo[$i]}"
                    record_time "HPRv3_WG400_PMM_Standalone" end "PSU_${address}_PMM_Information_Check;${PMMInfo[$i]}" "${PMM_Array[$i]}" "FAIL" "${RackSN}"
                    record_time "HPRv3_WG400_PMM_Standalone" total "HPRv3_WG400_PMM_Standalone;NA" "NA" "FAIL" "${RackSN}"
                    return 1
                else
                    show_pass_msg "Rack Module Test -- PSU_${address}_PMM_Information_Check Test -> ${PMMInfo[$i]}"
                    record_time "HPRv3_WG400_PMM_Standalone" end "PSU_${address}_PMM_Information_Check;${PMMInfo[$i]}" "${PMM_Array[$i]}" "PASS" "${RackSN}"
                fi
            elif [ ${PMMInfo[$i]} == "PMM_FW_Revision" ];then                 
                logResultCheck "LogCheck" "${PMMInfo[$i]}<" "NF;${PMM_Array[$i]}" "${PMMLog}"                 
                if [ ${PIPESTATUS[0]} -ne 0 ];then                         
                    show_fail_msg "Rack Module Test -- PSU_${address}_PMM_Information_Check Test -> ${PMMInfo[$i]}"                         
                    record_time "HPRv3_WG400_PMM_Standalone" end "PSU_${address}_PMM_Information_Check;${PMMInfo[$i]}" "${PMM_Array[$i]}" "FAIL" "${RackSN}"                         
                    echo "Need to update the FW for PMM, continue the update process"
                    PMM_Update_Process "$address" "$PMMType" "$PMMVendor" "${PMM_Array[$i]}"
                    if [ ${PIPESTATUS[0]} -eq 0 ];then
                        echo "The PMM type ${PMMType} for vendor ${PMMVendor} already updated, check the FW again"
                        exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address} --reg-name ${PMMInfo[$i]}" "${wedge400IP}" | tee ${PMMLog}
                        logResultCheck "LogCheck" "${PMMInfo[$i]}<" "NF;${PMM_Array[$i]}" "${PMMLog}"
                        if [ ${PIPESTATUS[0]} -eq 0 ];then
                            echo "The PMM FW already update to ${PMM_Array[$i]}, continue the test"
                        else
                            echo "The PMM FW don't update to ${PMM_Array[$i]}, stop the test"
                            return 1
                        fi
                    else
                        echo "The PMM FW don't update to ${PMM_Array[$i]}, stop the test"
                        return 1
                    fi
                else                         
                    show_pass_msg "Rack Module Test -- PSU_${address}_PMM_Information_Check Test -> ${PMMInfo[$i]}"                         
                    record_time "HPRv3_WG400_PMM_Standalone" end "PSU_${address}_PMM_Information_Check;${PMMInfo[$i]}" "${PMM_Array[$i]}" "PASS" "${RackSN}"                 
                fi  
            else
                logResultCheck "LogCheck" "${PMMInfo[$i]}<" "NF;${PMM_Array[$i]}" "${PMMLog}"
                if [ ${PIPESTATUS[0]} -ne 0 ];then
                    show_fail_msg "Rack Module Test -- PSU_${address}_PMM_Information_Check Test -> ${PMMInfo[$i]}"
                    record_time "HPRv3_WG400_PMM_Standalone" end "PSU_${address}_PMM_Information_Check;${PMMInfo[$i]}" "${PMM_Array[$i]}" "FAIL" "${RackSN}"
                    record_time "HPRv3_WG400_PMM_Standalone" total "HPRv3_WG400_PMM_Standalone;NA" "NA" "FAIL" "${RackSN}"
                    return 1
                else
                    show_pass_msg "Rack Module Test -- PSU_${address}_PMM_Information_Check Test -> ${PMMInfo[$i]}"
                    record_time "HPRv3_WG400_PMM_Standalone" end "PSU_${address}_PMM_Information_Check;${PMMInfo[$i]}" "${PMM_Array[$i]}" "PASS" "${RackSN}"
                fi
            fi
        done
    done

    for address in ${HPR_PMM_BBU_AddressArr[@]};do
        record_time "HPRv3_WG400_PMM_Standalone" start "BBU_PMM_Check;${address}" "${address}" "NA" "${RackSN}"
        exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address}" "${wedge400IP}" | tee ${PMMLog}
        echo "BBU PMM Address and Modbus Address : ${address} Check Test"       
        logResultCheck "CheckResult" "Device Address;NF" "${address}" "${PMMLog}"
        if [ ${PIPESTATUS[0]} -ne 0 ];then
            show_fail_msg "Rack Module Information Test -- BBU PMM Address and Modbus Check Test -- Address ${address} "
            record_time "HPRv3_WG400_PMM_Standalone" end "BBU_PMM_Check;${address}" "${address}" "FAIL" "${RackSN}"
            record_time "HPRv3_WG400_PMM_Standalone" total "HPRv3_WG400_PMM_Standalone;NA" "NA" "FAIL" "${RackSN}"
            return 1
        else
            show_pass_msg "Rack Module Information Test -- BBU PMM Address and Modbus Check Test -- Address ${address} "
            record_time "HPRv3_WG400_PMM_Standalone" end "BBU_PMM_Check;${address}" "${address}" "PASS" "${RackSN}"
        fi

        exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address} --reg-name PMM_MFR_Name" "${wedge400IP}" | tee ${PMMLog}
        PMMVendor=$(cat ${PMMLog} | grep "PMM_MFR_Name<0x0008>" | awk '{print$NF}' | tr -d '"')

        exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address} --reg-name \"Device Type\"" "${wedge400IP}" | tee ${PMMLog}
        PMMType=$(cat ${PMMLog} | grep "Device Type:" | awk '{print$NF}')

        if [ ${PMMType} == "ORV3_HPR_PMM_BBU" ];then
            if [ ${PMMVendor} == "Panasonic" ];then
                declare -a PMM_Array=("${PANA_BBUPMM_Data_Array[@]}")
            elif [ ${PMMVendor} == "Delta" ];then
                declare -a PMM_Array=("${DELTA_BBUPMM_Data_Array[@]}")
            else
                echo "Can't get correct BBU PMM vendor, stop the test"
                return 1
            fi
        else
            echo "The address is not belongs to BBU PMM, stop the test"
            return 1
        fi

        echo "PMM Module Inforamtion Check for address : ${address}" 
        PMMInfo=("PMM_FBPN" "PMM_MFR_Model" "PMM_MFR_Date" "PMM_MFR_Serial" "PMM_HW_Revision" "PMM_FW_Revision")

        for i in "${!PMMInfo[@]}"; do
            exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address} --reg-name ${PMMInfo[$i]}" "${wedge400IP}" | tee ${PMMLog}
            record_time "HPRv3_WG400_PMM_Standalone" start "BBU_${address}_PMM_Information_Check;${PMMInfo[$i]}" "${PMM_Array[$i]}" "NA" "${RackSN}"

            if [ ${PMMInfo[$i]} == "PMM_MFR_Date" ];then
                logResultCheck "CheckEGREPFormat" "${PMMInfo[$i]}<" "NF;${PMM_Array[$i]}" "${PMMLog}"
                if [ ${PIPESTATUS[0]} -ne 0 ];then
                    show_fail_msg "Rack Module Test -- BBU_${address}_PMM_Information_Check Test -> ${PMMInfo[$i]}"
                    record_time "HPRv3_WG400_PMM_Standalone" end "BBU_${address}_PMM_Information_Check;${PMMInfo[$i]}" "${PMM_Array[$i]}" "FAIL" "${RackSN}"
                    record_time "HPRv3_WG400_PMM_Standalone" total "HPRv3_WG400_PMM_Standalone;NA" "NA" "FAIL" "${RackSN}"
                    return 1
                else
                    show_pass_msg "Rack Module Test -- BBU_${address}_PMM_Information_Check Test -> ${PMMInfo[$i]}"
                    record_time "HPRv3_WG400_PMM_Standalone" end "BBU_${address}_PMM_Information_Check;${PSU}" "[1]" "PASS" "${RackSN}"
                fi
            elif [ ${PMMInfo[$i]} == "PMM_MFR_Serial" ];then
                logResultCheck "CheckEGREPValue" "${PMMInfo[$i]}<" "NF;${PMM_Array[$i]}" "${PMMLog}"
		        if [ ${PIPESTATUS[0]} -ne 0 ];then
                    show_fail_msg "Rack Module Test -- BBU_${address}_PMM_Information_Check Test -> ${PMMInfo[$i]}"
                    record_time "HPRv3_WG400_PMM_Standalone" end "BBU_${address}_PMM_Information_Check;${PMMInfo[$i]}" "${PMM_Array[$i]}" "FAIL" "${RackSN}"
                    record_time "HPRv3_WG400_PMM_Standalone" total "HPRv3_WG400_PMM_Standalone;NA" "NA" "FAIL" "${RackSN}"
                    return 1
                else
                    show_pass_msg "Rack Module Test -- BBU_${address}_PMM_Information_Check Test -> ${PMMInfo[$i]}"
                    record_time "HPRv3_WG400_PMM_Standalone" end "BBU_${address}_PMM_Information_Check;${PMMInfo[$i]}" "${PMM_Array[$i]}" "PASS" "${RackSN}"
                fi
            elif [ ${PMMInfo[$i]} == "PMM_FW_Revision" ];then                 
				logResultCheck "LogCheck" "${PMMInfo[$i]}<" "NF;${PMM_Array[$i]}" "${PMMLog}"                 
				if [ ${PIPESTATUS[0]} -ne 0 ];then                         
					show_warn_msg "Rack Module Test -- PSU_${address}_PMM_Information_Check Test -> ${PMMInfo[$i]}"                                             
					echo "Need to update the FW for PMM, continue the update process"
                    PMM_Update_Process "$address" "$PMMType" "$PMMVendor"
                    if [ ${PIPESTATUS[0]} -eq 0 ];then
                        echo "The PMM type ${PMMType} for vendor ${PMMVendor} already updated, check the FW again"
                        exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address} --reg-name ${PMMInfo[$i]}" "${wedge400IP}" | tee ${PMMLog}
                        logResultCheck "LogCheck" "${PMMInfo[$i]}<" "NF;${PMM_Array[$i]}" "${PMMLog}"
                        if [ ${PIPESTATUS[0]} -eq 0 ];then
                            echo "The PMM FW already update to ${PMM_Array[$i]}, continue the test"
                        else
                            echo "The PMM FW don't update to ${PMM_Array[$i]}, stop the test"
                            return 1
                        fi
                    else
                        echo "The PMM FW don't update to ${PMM_Array[$i]}, stop the test"
                        return 1
                    fi
				else                         
					show_pass_msg "Rack Module Test -- BBU_${address}_PMM_Information_Check Test -> ${PMMInfo[$i]}"                         
					record_time "HPRv3_WG400_PMM_Standalone" end "BBU_${address}_PMM_Information_Check;${PMMInfo[$i]}" "${PMM_Array[$i]}" "PASS" "${RackSN}"                 
				fi  
            else
                logResultCheck "LogCheck" "${PMMInfo[$i]}<" "NF;${PMM_Array[$i]}" "${PMMLog}"
                if [ ${PIPESTATUS[0]} -ne 0 ];then
                    show_fail_msg "Rack Module Test -- BBU_${address}_PMM_Information_Check Test -> ${PMMInfo[$i]}"
                    record_time "HPRv3_WG400_PMM_Standalone" end "BBU_${address}_PMM_Information_Check;${PMMInfo[$i]}" "${PMM_Array[$i]}" "FAIL" "${RackSN}"
                    record_time "HPRv3_WG400_PMM_Standalone" total "HPRv3_WG400_PMM_Standalone;NA" "NA" "FAIL" "${RackSN}"
                    return 1
                else
                    show_pass_msg "Rack Module Test -- BBU_${address}_PMM_Information_Check Test -> ${PMMInfo[$i]}"
                    record_time "HPRv3_WG400_PMM_Standalone" end "BBU_${address}_PMM_Information_Check;${PMMInfo[$i]}" "${PMM_Array[$i]}" "PASS" "${RackSN}"
                fi
            fi
        done
    done

}

base=$(basename $0)
testitem=${base%.*}
filename="${testitem}.log"
LOGFOLDER=${LOGPATH}/${RackSN}
startTime=$(date "+%F_%T" | sed -e "s/-//g" -e "s/://g")
PMMLog=${LOGFOLDER}/PMMLog.txt
GPIOLog=${LOGFOLDER}/GPIOLog.txt
RackmonLog=${LOGFOLDER}/RackMonLog.txt
LOGFILE=${LOGFOLDER}/log.txt
PMMUpdateLog=${LOGFOLDER}/PMMUpdate.txt

show_title_msg "${testitem}" | tee ${LOGFILE}
START=$(date)

record_time "HPRv3_WG400_PMM_Standalone" initial "" "" "" "$RackSN" 

Normal_HPRv3_GPIO_test | tee -a ${LOGFILE}
if [ "${PIPESTATUS[0]}" -ne "0" ];then
	show_error_msg "HPRv3 PMM Standalone Test" | tee -a ${LOGFILE}
        show_fail | tee -a ${LOGFILE}
    	finalLog=${RackIPN}_${RackSN}_${RackAsset}_HPRv3_${switch_index}_PMMSTANDALONE_FAIL_${startTime}.log
    	record_time "HPRv3_WG400_PMM_Standalone" show "" "" "" "${RackSN}" | tee -a ${LOGFILE}
    	cat ${LOGPATH}/${RackSN}/summary_table_${station}.conf | tee -a ${LOGFILE}
    	cat ${LOGFILE} > ${LOGPATH}/${RackSN}/${finalLog}
    	cp ${LOGPATH}/${RackSN}/${finalLog} /log/hprv3 > /dev/null
    	exit 1
fi

Normal_Wedge400_Gen_Whole_Log | tee -a ${LOGFILE}
if [ "${PIPESTATUS[0]}" -ne "0" ];then
	show_error_msg "HPRv3 PMM Standalone Test" | tee -a ${LOGFILE}
        show_fail | tee -a ${LOGFILE}
    	finalLog=${RackIPN}_${RackSN}_${RackAsset}_HPRv3_${switch_index}_PMMSTANDALONE_FAIL_${startTime}.log
    	record_time "HPRv3_WG400_PMM_Standalone" show "" "" "" "${RackSN}" | tee -a ${LOGFILE}
    	cat ${LOGPATH}/${RackSN}/summary_table_${station}.conf | tee -a ${LOGFILE}
    	cat ${LOGFILE} > ${LOGPATH}/${RackSN}/${finalLog}
    	cp ${LOGPATH}/${RackSN}/${finalLog} /log/hprv3 > /dev/null
    	exit 1
fi

Normal_HPRv3_PMM_Funtional_test | tee -a ${LOGFILE}
if [ "${PIPESTATUS[0]}" -ne "0" ];then
    show_error_msg "HPRv3 PMM Standalone Test" | tee -a ${LOGFILE}
    show_fail | tee -a ${LOGFILE}
    finalLog=${RackIPN}_${RackSN}_${RackAsset}_HPRv3_${switch_index}_PMMSTANDALONE_FAIL_${startTime}.log
    record_time "HPRv3_WG400_PMM_Standalone" total "HPRv3_WG400_PMM_Standalone;NA" "NA" "FAIL" "${RackSN}"
    record_time "HPRv3_WG400_PMM_Standalone" show "" "" "" "${RackSN}" | tee -a ${LOGFILE}
    cat ${LOGPATH}/${RackSN}/summary_table_${station}.conf | tee -a ${LOGFILE}
    cat ${LOGFILE} > ${LOGPATH}/${RackSN}/${finalLog}
    cp ${LOGPATH}/${RackSN}/${finalLog} /log/hprv3 > /dev/null
    exit 1
fi

show_pass_msg "HPRv3 PMM Standalone Test" | tee -a ${LOGFILE}
show_pass | tee -a ${LOGFILE}
finalLog=${RackIPN}_${RackSN}_${RackAsset}_HPRv3_${switch_index}_PMMSTANDALONE_PASS_${startTime}.log
record_time "HPRv3_WG400_PMM_Standalone" total "HPRv3_WG400_PMM_Standalone;NA" "NA" "PASS" "${RackSN}"
record_time "HPRv3_WG400_PMM_Standalone" show "" "" "" "${RackSN}" | tee -a ${LOGFILE}
#cat ${LOGPATH}/${RackSN}/summary_table_${station}.conf | tee -a ${LOGFILE}
cat ${LOGFILE} > ${LOGPATH}/${RackSN}/${finalLog}
cp ${LOGPATH}/${RackSN}/${finalLog} /log/hprv3 > /dev/null
exit 0
