#!/bin/bash
# Version       : v1.0
# Function      : Execute Get bmc mac from node folder and ping if the IP is alive. 
# History       :
# 2024-10-30    | initial version
source ../commonlib
source ../record_time

execscript=$(basename $BASH_SOURCE)
echo "Current use script : ${execscript}"

set -x

switch_index=1

while getopts s:i: OPT; do
    case "${OPT}" in
        "s")
            RackSN=${OPTARG}
           	check_sn ${RackSN}
		    RackIPN=$(cat ${LOGPATH}/${RackSN}/rackipn.txt)
            RackAsset=$(cat ${LOGPATH}/${RackSN}/assetid.txt)
            wedge400IP=$(cat ${LOGPATH}/${RackSN}/RUSW/${switch_index}/mac_ip.txt)
            ;;
        "i")
            index=${OPTARG}
            if [ -z "${index}" ];then
                print_help
                return 1
            fi 
        ;;
        *)
            print_help
            return 1
        ;;
    esac
done

PSU_Update_Process()
{
    UpdateAddress=$1
    PSUType=$2
    PSUVendor=$3
    TargetVer=$4
    echo "Need updated address ${address} with PSU type : ${PSUType} and PSU vendor : ${PSUVendor}"

    PSUImage=$(ls $TOOLPATH/${PSUType}/${PSUVendor}/)
    if [ ${PSUVendor^^} == "AEL" ] && [ ${PSUType} == "ORV3_HPR_PSU" ];then
        update_status "$SN" "$folder" "$index" "$testitem" "PSU Update" 1
        echo "Send the update image to Wedge400"
        echo "Command : sshpass -p "0penBmc" scp $TOOLPATH/${PSUType}/${PSUVendor}/${PSUImage} ${wedge400IP}:/tmp"
        sshpass -p "0penBmc" sshpass -p "0penBmc" scp $TOOLPATH/${PSUType}/${PSUVendor}/${PSUImage} ${wedge400IP}:/tmp
        if [ ${PIPESTATUS[0]} -ne 0 ];then
            echo "Can't send the update image into Wedge400"
            show_fail_msg "Rack Module Information Test -- SCP Image"
            record_time "HPRv3_WG400_PSU_Standalone" total "HPRv3_WG400_PSU_Standalone;NA" "NA" "FAIL" "${RackSN}"
            update_status "$SN" "$folder" "$index" "$testitem" "PSU Update" 3
            return 1
        else
            show_pass_msg "Rack Module Information Test -- SCP Image"
        fi

        echo "Update command : flock /tmp/modbus_dynamo_solitonbeam.lock /usr/local/bin/psu-update-aei.py --addr ${UpdateAddress} -–device hpr /tmp/${PSUImage}"
        exeucte_test "flock /tmp/modbus_dynamo_solitonbeam.lock /usr/local/bin/psu-update-aei.py --addr ${UpdateAddress} --device hpr /tmp/${PSUImage}" "${wedge400IP}" | tee ${PSUUpdateLog} 
        Status=$(cat ${PSUUpdateLog} | grep "Upgrade success" | wc -l)
        newFWVer=$(cat ${PSUUpdateLog}  | grep -A 4 "Upgrade success" | grep Version | awk -F ':' '{print$2}' | tr -d ' ')
        if [ ${Status} -eq 1 ];then
            if [ ${newFWVer} == "$TargetVer" ];then
                echo "The vendor ${PSUVendor} for ${PSUType} already update to target version ${TargetVer}"
            else
                echo "The vendor ${PSUVendor} for ${PSUType} can't update to target version ${TargetVer}, stop the test"
                update_status "$SN" "$folder" "$index" "$testitem" "PSU Update" 3
                return 1
            fi
        else    
            echo "The vendor ${PSUVendor} for ${PSUType} can't update to target version ${TargetVer}, stop the test"
            update_status "$SN" "$folder" "$index" "$testitem" "PSU Update" 3
            return 1
        fi
    elif [ ${PSUVendor^^} == "DELTA" ] && [ ${PSUType} == "ORV3_HPR_PSU" ] ;then

        echo "Send the update image to Wedge400"
        echo "Command : sshpass -p "0penBmc" scp $TOOLPATH/${PSUType}/${PSUVendor}/${PSUImage} ${wedge400IP}:/tmp"
        sshpass -p "0penBmc" sshpass -p "0penBmc" scp $TOOLPATH/${PSUType}/${PSUVendor}/${PSUImage} ${wedge400IP}:/tmp
        if [ ${PIPESTATUS[0]} -ne 0 ];then
            echo "Can't send the update image into Wedge400"
            show_fail_msg "Rack Module Information Test -- SCP Image"
            record_time "HPRv3_WG400_PSU_Standalone" total "HPRv3_WG400_PSU_Standalone;NA" "NA" "FAIL" "${RackSN}"
            return 1
        else
            show_pass_msg "Rack Module Information Test -- SCP Image"
        fi

        echo "Update command : flock /tmp/modbus_dynamo_solitonbeam.lock /usr/local/bin/psu-update-delta-orv3.py --addr ${UpdateAddress} --key 0x06854137C758A5B6 /tmp/${PSUImage}"
        exeucte_test "flock /tmp/modbus_dynamo_solitonbeam.lock /usr/local/bin/psu-update-delta-orv3.py --addr ${UpdateAddress} --key 0x06854137C758A5B6 /tmp/${PSUImage}" "${wedge400IP}" | tee ${PSUUpdateLog} 
        Status=$(cat ${PSUUpdateLog} | grep "Upgrade success" | wc -l)
        newFWVer=$(cat ${PSUUpdateLog}  | grep -A 4 "Upgrade success" | grep Version | awk -F ':' '{print$2}' | tr -d ' ')
        if [ ${Status} -eq 1 ];then
            if [ ${newFWVer} == "$TargetVer" ];then
                echo "The vendor ${PSUVendor} for ${PSUType} already update to target version ${TargetVer}"
            else
                echo "The vendor ${PSUVendor} for ${PSUType} can't update to target version ${TargetVer}, stop the test"
                update_status "$SN" "$folder" "$index" "$testitem" "PSU Update" 3
                return 1
            fi
        else    
            echo "The vendor ${PSUVendor} for ${PSUType} can't update to target version ${TargetVer}, stop the test"
            update_status "$SN" "$folder" "$index" "$testitem" "PSU Update" 3
            return 1
        fi
    else
        echo "Can't get correct PSU vendor or PSU type, stop the test"
        update_status "$SN" "$folder" "$index" "$testitem" "PSU Update" 3
        return 1
    fi
    update_status "$SN" "$folder" "$index" "$testitem" "PSU Update" 2
}

Normal_HPRv3_PSU_Funtional_test()
{ 
    HPR_PSU_AddressArr=($(cat ${RackmonLog} | grep -B 1 "ORV3_HPR_PSU" | grep "Device Address" | awk '{print$NF}'))
 
    echo "HPR PSU Address : ${HPR_PSU_AddressArr[@]}"
    PSU_Array=()
    declare -a ARTESYN_PSU_INFO_ARRAY=("03-100049" "700-037147-0000" "^[0-9]{2}/[0-9]{4}$" "PSU3AEL" "A00" "007")
    #declare -a ARTESYN_PSU_INFO_ARRAY=("03-100049" "700-037147-0000" "[0-5][0-9]/202[4-5]" "PSU3AEL" "A00" "007")
    declare -a DELTA_PSU_INFO_ARRAY=("03-100038" "ECD17010021" "^[0-9]{2}/[0-9]{4}$" "P1HPDET" "8" "1.5.1.04111.3213")


    for address in ${HPR_PSU_AddressArr[@]};do
        update_status "$SN" "$folder" "$index" "$testitem" "PSU Address Check" 1
	    record_time "HPRv3_WG400_PSU_Standalone" start "PSU Address ${address} Check" "${address}" "NA" "${RackSN}"
        echo "PSU Address : ${address} Check Test"
        exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address}" "${wedge400IP}" | tee ${PSULog} 
        logResultCheck "CheckResult" "Device Address;NF" "${address}" "${PSULog}"
        if [ ${PIPESTATUS[0]} -ne 0 ];then
            show_fail_msg "Rack Module Information Test -- ${address} PSU Address Check Test "
		    record_time "HPRv3_WG400_PSU_Standalone" end "PSU Address ${address} Check" "${address}" "FAIL" "${RackSN}"
            record_time "HPRv3_WG400_PSU_Standalone" total "HPRv3_WG400_PSU_Standalone;NA" "NA" "FAIL" "${RackSN}"
            update_status "$SN" "$folder" "$index" "$testitem" "PSU Address Check" 3
            return 1
        else
            show_pass_msg "Rack Module Information Test -- ${address} PSU Address Check Test "
		    record_time "HPRv3_WG400_PSU_Standalone" end "PSU Address ${address} Check" "${address}" "PASS" "${RackSN}"
            update_status "$SN" "$folder" "$index" "$testitem" "PSU Address Check" 2
        fi
      
        update_status "$SN" "$folder" "$index" "$testitem" "PSU Info Check" 1
	    exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address} --reg-name PSU_MFR_Serial" "${wedge400IP}" | tee ${PSULog}
        PSUVendor=$(cat ${PSULog} | grep "PSU_MFR_Serial<" | awk '{print$NF}' | cut -c 10-12)
	    
        exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address} --reg-name \"Device Type\"" "${wedge400IP}" | tee ${PSULog}
        PSUType=$(cat ${PSULog} | grep "Device Type:" | awk '{print$NF}')

        if [ ${PSUType} == "ORV3_HPR_PSU" ];then
            if [ ${PSUVendor} == "AEL" ];then
                declare -a PSU_Array=("${ARTESYN_PSU_INFO_ARRAY[@]}")
		echo "${PSU_Array[@]}"
            elif [ ${PSUVendor} == "DET" ];then
                declare -a PSU_Array=("${DELTA_PSU_INFO_ARRAY[@]}")
		echo "${PSU_Array[@]}"
            else
                echo "Can't get correct PSU vendor, stop the test"
                update_status "$SN" "$folder" "$index" "$testitem" "PSU Info Check" 3
                return 1
            fi
        else
            echo "The address is not belongs to PSU, stop the test"
            update_status "$SN" "$folder" "$index" "$testitem" "PSU Info Check" 3
            return 1
        fi

        echo "PSU Module Infotmation Check for address : ${address}"
        PSUInfo=("PSU_FBPN" "PSU_MFR_Model" "PSU_MFR_Date" "PSU_MFR_Serial" "PSU_HW_Revision" "PSU_FW_Revision")
	        
	    for i in "${!PSUInfo[@]}"; do
            exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address} --reg-name ${PSUInfo[$i]}" "${wedge400IP}" | tee ${PSULog}
            record_time "HPRv3_WG400_PSU_Standalone" start "PSU_${address}_Information_Check;${PSUInfo[$i]}" "${PSU_Array[$i]}" "NA" "${RackSN}"

            if [ ${PSUInfo[$i]} == "PSU_MFR_Date" ];then
                logResultCheck "CheckEGREPFormat" "${PSUInfo[$i]}<" "NF;${PSU_Array[$i]}" "${PSULog}"
                if [ ${PIPESTATUS[0]} -ne 0 ];then
                    show_fail_msg "Rack Module Test -- PSU_${address}_Information_Check Test -> ${PSUInfo[$i]}"
                    record_time "HPRv3_WG400_PSU_Standalone" end "PSU_${address}_Information_Check;${PSUInfo[$i]}" "${PSU_Array[$i]}" "FAIL" "${RackSN}"
                    record_time "HPRv3_WG400_PSU_Standalone" total "HPRv3_WG400_PSU_Standalone;NA" "NA" "FAIL" "${RackSN}"
                    update_status "$SN" "$folder" "$index" "$testitem" "PSU Info Check" 3
                    return 1
                else
                    show_pass_msg "Rack Module Test -- PSU_${address}_Information_Check Test -> ${PSUInfo[$i]}"
                    record_time "HPRv3_WG400_PSU_Standalone" end "PSU_${address}_Information_Check;${PSUInfo[$i]}" "${PSU_Array[$i]}" "PASS" "${RackSN}"
                    update_status "$SN" "$folder" "$index" "$testitem" "PSU Info Check" 2
                fi
            elif [ ${PSUInfo[$i]} == "PSU_FW_Revision" ];then                 
                logResultCheck "LogCheck" "${PSUInfo[$i]}<" "NF;${PSU_Array[$i]}" "${PSULog}"                 
                if [ ${PIPESTATUS[0]} -ne 0 ];then                         
                    show_fail_msg "Rack Module Test -- PSU_${address}_Information_Check Test -> ${PSUInfo[$i]}"                         
                    record_time "HPRv3_WG400_PSU_Standalone" end "PSU_${address}_Information_Check;${PSUInfo[$i]}" "${PSU_Array[$i]}" "FAIL" "${RackSN}"                         
                    echo "Need to update the FW for PSU, continue the update process"
                    PSU_Update_Process "$address" "$PSUType" "$PSUVendor" "${PSU_Array[$i]}"
                    if [ ${PIPESTATUS[0]} -eq 0 ];then
                        echo "The PSU type ${PSUType} for vendor ${PSUVendor} already updated, check the FW again"
                        exeucte_test "/usr/local/bin/rackmoncli data --dev-addr ${address} --reg-name ${PSUInfo[$i]}" "${wedge400IP}" | tee ${PSULog}
                        logResultCheck "LogCheck" "${PSUInfo[$i]}<" "NF;${PSU_Array[$i]}" "${PSULog}"
                        if [ ${PIPESTATUS[0]} -eq 0 ];then
                            echo "The PSU FW already update to ${PSU_Array[$i]}, continue the test"
                        else
                            echo "The PSU FW don't update to ${PSU_Array[$i]}, stop the test"
                            update_status "$SN" "$folder" "$index" "$testitem" "PSU Info Check" 3
                            return 1
                        fi
                    else
                        echo "The PSU FW don't update to ${PSU_Array[$i]}, stop the test"
                        update_status "$SN" "$folder" "$index" "$testitem" "PSU Info Check" 3
                        return 1
                    fi
                else                         
                    show_pass_msg "Rack Module Test -- PSU_${address}_Information_Check Test -> ${PSUInfo[$i]}"                         
                    record_time "HPRv3_WG400_PSU_Standalone" end "PSU_${address}_Information_Check;${PSUInfo[$i]}" "${PSU_Array[$i]}" "PASS" "${RackSN}"      
                    update_status "$SN" "$folder" "$index" "$testitem" "PSU Info Check" 2           
                fi 
            elif [ ${PSUInfo[$i]} == "PSU_MFR_Serial" ];then
                logResultCheck "CheckEGREPValue" "${PSUInfo[$i]}<" "NF;${PSU_Array[$i]}" "${PSULog}"
                if [ ${PIPESTATUS[0]} -ne 0 ];then
                    show_fail_msg "Rack Module Test -- PSU_${address}_Information_Check Test -> ${PSUInfo[$i]}"
                    record_time "HPRv3_WG400_PSU_Standalone" end "PSU_${address}_Information_Check;${PSUInfo[$i]}" "${PSU_Array[$i]}" "FAIL" "${RackSN}"
                    record_time "HPRv3_WG400_PSU_Standalone" total "HPRv3_WG400_PSU_Standalone;NA" "NA" "FAIL" "${RackSN}"
                    update_status "$SN" "$folder" "$index" "$testitem" "PSU Info Check" 3
                    return 1
                else
                    show_pass_msg "Rack Module Test -- PSU_${address}_Information_Check Test -> ${PSUInfo[$i]}"
                    record_time "HPRv3_WG400_PSU_Standalone" end "PSU_${address}_Information_Check;${PSUInfo[$i]}" "${PSU_Array[$i]}" "PASS" "${RackSN}"
                    update_status "$SN" "$folder" "$index" "$testitem" "PSU Info Check" 2
                fi
             else
                logResultCheck "LogCheck" "${PSUInfo[$i]}<" "NF;${PSU_Array[$i]}" "${PSULog}"
                if [ ${PIPESTATUS[0]} -ne 0 ];then
                    show_fail_msg "Rack Module Test -- PSU_${address}_Information_Check Test -> ${PSUInfo[$i]}"
                    record_time "HPRv3_WG400_PSU_Standalone" end "PSU_${address}_Information_Check;${PSUInfo[$i]}" "${PSU_Array[$i]}" "FAIL" "${RackSN}"
                    record_time "HPRv3_WG400_PSU_Standalone" total "HPRv3_WG400_PSU_Standalone;NA" "NA" "FAIL" "${RackSN}"
                    update_status "$SN" "$folder" "$index" "$testitem" "PSU Info Check" 3
                    return 1
                else
                    show_pass_msg "Rack Module Test -- PSU_${address}_Information_Check Test -> ${PSUInfo[$i]}"
                    record_time "HPRv3_WG400_PSU_Standalone" end "PSU_${address}_Information_Check;${PSUInfo[$i]}" "${PSU_Array[$i]}" "PASS" "${RackSN}"
                    update_status "$SN" "$folder" "$index" "$testitem" "PSU Info Check" 2
                fi
            fi
        done
    done
}


base=$(basename $0)
testitem=${base%.*}
filename="${testitem}.log"
LOGFOLDER=${LOGPATH}/${RackSN}
startTime=$(date "+%F_%T" | sed -e "s/-//g" -e "s/://g")
PSULog=${LOGFOLDER}/PSULog.txt
PSUUpdateLog=${LOGFOLDER}/PSUUpdateLog.txt
RackmonLog=${LOGFOLDER}/RackMonLog.txt
LOGFILE=${LOGFOLDER}/log.txt

show_title_msg "${testitem}" | tee ${LOGFILE}
START=$(date)

record_time "HPRv3_WG400_PSU_Standalone" initial "" "" "" "$RackSN" 
ssh-keygen -R "${wedge400IP}" > /dev/null

Normal_HPRv3_PSU_Funtional_test | tee -a ${LOGFILE}
if [ "${PIPESTATUS[0]}" -ne "0" ];then
	show_error_msg "HPRv3 PSU Standalone Test" | tee -a ${LOGFILE}
        show_fail | tee -a ${LOGFILE}
   	finalLog=${RackIPN}_${RackSN}_${RackAsset}_HPRv3_${switch_index}_PSUSTANDALONE_FAIL_${startTime}.log
   	record_time "HPRv3_WG400_PSU_Standalone" show "" "" "" "${RackSN}" | tee -a ${LOGFILE}
        cat ${LOGPATH}/${RackSN}/summary_table_${station}.conf | tee -a ${LOGFILE}
	cat ${LOGFILE} > ${LOGPATH}/${RackSN}/${finalLog}
   	cp ${LOGPATH}/${RackSN}/${finalLog} /log/hprv3 > /dev/null
   	exit 1
fi

show_pass_msg "HPRv3 PSU Standalone Test" | tee -a ${LOGFILE}
show_pass | tee -a ${LOGFILE}
finalLog=${RackIPN}_${RackSN}_${RackAsset}_HPRv3_${switch_index}_PSUSTANDALONE_PASS_${startTime}.log
record_time "HPRv3_WG400_PSU_Standalone" show "" "" "" "${RackSN}" | tee -a ${LOGFILE}
#cat ${LOGPATH}/${RackSN}/summary_table_${station}.conf | tee -a ${LOGFILE}
cat ${LOGFILE} > ${LOGPATH}/${RackSN}/${finalLog}
cp ${LOGPATH}/${RackSN}/${finalLog} /log/hprv3 > /dev/null
exit 0
